import { toolIcon } from "./icons.js";
import { FileManager } from "../classes/FileManager.js";
import { PageManager } from "../classes/PageManager.js";
import { ExportManager } from "../classes/ExportManager.js";
import { HistoryManager } from "../classes/HistoryManager.js";
import { PreviewManager } from "../classes/PreviewManager.js";

const $ = (selector) => document.querySelector(selector);

const categories = [
  {
    id: "pdf-tools",
    title: "أدوات PDF",
    tools: [
      [
        "merge",
        "PDF",
        "دمج وترتيب PDF",
        "اجمع الملفات ورتّب الصفحات قبل التصدير.",
      ],
      [
        "splitRanges",
        "CUT",
        "تقسيم PDF",
        "قسّم الملف باستخدام نطاقات الصفحات.",
      ],
      [
        "splitEach",
        "ZIP",
        "تقسيم كل صفحة",
        "احفظ كل صفحة في ملف PDF مستقل داخل ZIP.",
      ],
      ["extract", "OUT", "استخراج صفحات", "صدّر الصفحات المحددة فقط."],
      ["delete", "DEL", "حذف صفحات", "أنشئ نسخة دون الصفحات المحددة."],
      ["compress", "ZIP", "ضغط PDF", "ضغط بصري قد يقلل قابلية البحث في النص."],
      ["rotate", "↻", "تدوير وترتيب", "دوّر الصفحات ورتّبها قبل التصدير."],
      ["repair", "FIX", "إعادة حفظ PDF", "جرّب إنشاء نسخة جديدة من صفحات PDF."],
    ],
  },
  {
    id: "image-tools",
    title: "أدوات الصور",
    tools: [
      ["images", "JPG", "PDF إلى JPG", "صدّر الصفحات كصور JPG داخل ZIP."],
      ["imagesPng", "PNG", "PDF إلى PNG", "صور واضحة دون فقد الجودة داخل ZIP."],
      ["imagesWebp", "WEBP", "PDF إلى WebP", "حوّل الصفحات إلى صور WebP للاستخدام على الويب."],
      ["imagesPdf", "JPG", "صور إلى PDF", "اجمع صور JPG وPNG في ملف PDF."],
    ],
  },
  {
    id: "text-tools",
    title: "النصوص وOCR",
    tools: [
      [
        "text",
        "TXT",
        "استخراج النص",
        "استخرج النص المضمّن في صفحات PDF إلى TXT.",
      ],
      ["ocr", "OCR", "OCR إلى Word", "استخرج النص من صفحات PDF المصوّرة."],
    ],
  },
  {
    id: "excel-tools",
    title: "Excel وCSV",
    tools: [
      {
        icon: "XLS",
        title: "أدوات Excel",
        description: "قريبًا: معاينة الجداول وتنظيف البيانات وتحويل الملفات.",
        disabled: true,
      },
      {
        icon: "CSV",
        title: "أدوات CSV",
        description: "قريبًا: فتح ملفات CSV وتنظيمها وتصديرها.",
        disabled: true,
      },
    ],
  },
  {
    id: "more-tools",
    title: "أدوات أخرى",
    tools: [
      {
        icon: "DOC",
        title: "أدوات Word",
        description: "قسم مستقبلي لتحويل المستندات وتجهيزها.",
        disabled: true,
      },
      {
        icon: "ZIP",
        title: "أدوات الملفات المضغوطة",
        description: "قسم مستقبلي للتعامل مع ملفات ZIP ومحتوياتها.",
        disabled: true,
      },
      {
        icon: "MORE",
        title: "أدوات إضافية",
        description: "سنضيف هنا أدوات جديدة حسب احتياجك.",
        disabled: true,
      },
    ],
  },
];

categories.splice(3, 0, {
  id: "quick-tools", title: "إنجاز سريع", tools: [
    ["reversePdf", "PDF", "عكس ترتيب PDF", "نزّل نسخة بترتيب الصفحات من الأخيرة إلى الأولى."],
    ["oddPdf", "1·3", "الصفحات الفردية", "استخرج الصفحات ١، ٣، ٥… في ملف واحد."],
    ["evenPdf", "2·4", "الصفحات الزوجية", "استخرج الصفحات ٢، ٤، ٦… في ملف واحد."],
    ["splitHalf", "½", "تقسيم إلى نصفين", "قسّم الملف تلقائيًا إلى جزأين داخل ZIP."]
  ]
});

const templateGroups = [["convert-templates","تحويل PDF",[["pdfWord","DOC","PDF إلى Word"],["pdfPowerpoint","PPT","PDF إلى PowerPoint"],["pdfExcel","XLS","PDF إلى Excel"],["wordPdf","DOC","Word إلى PDF"],["powerpointPdf","PPT","PowerPoint إلى PDF"],["excelPdf","XLS","Excel إلى PDF"],["htmlPdf","HTML","HTML إلى PDF"],["pdfMarkdown","MD","PDF إلى Markdown"]]],["edit-templates","تعديل PDF",[["editPdf","EDIT","تعديل PDF"],["signPdf","SIGN","توقيع PDF"],["watermarkPdf","WM","علامة مائية"],["numberPdf","123","ترقيم الصفحات"],["cropPdf","CROP","قص صفحات PDF"],["formsPdf","FORM","نماذج PDF"]]],["security-templates","حماية PDF",[["unlockPdf","LOCK","إزالة كلمة مرور PDF"],["protectPdf","LOCK","حماية PDF بكلمة مرور"],["redactPdf","HIDE","حجب البيانات الحساسة"]]],["optimize-templates","تحسين PDF",[["pdfArchive","PDF/A","PDF إلى PDF/A"],["scanPdf","SCAN","مسح إلى PDF"],["searchablePdf","OCR","PDF قابل للبحث"]]],["intelligence-templates","أدوات ذكية",[["comparePdf","DIFF","مقارنة PDF"],["summarizePdf","AI","تلخيص PDF"],["translatePdf","LANG","ترجمة PDF"]]],["workflow-templates","سير العمل",[["workflow","FLOW","إنشاء سير عمل"]]]];
const activatedTools = new Set(["watermarkPdf", "numberPdf", "pdfMarkdown", "pdfPowerpoint", "pdfWord", "comparePdf", "cropPdf"]);
const templateIds = new Set(templateGroups.flatMap(group => group[2].filter(tool => !activatedTools.has(tool[0])).map(tool => tool[0])));
templateGroups.forEach(([id,title,items]) => categories.push({id,title,tools:items.map(item => [...item, activatedTools.has(item[0]) ? ({pdfWord:"استخراج النص إلى Word قابل للتحرير؛ لا يستعيد تخطيط الملف. للصور استخدم OCR.",comparePdf:"مقارنة نصوص ملفين وإخراج تقرير بالفروق؛ لا يقارن الرسومات.",cropPdf:"إخفاء هوامش الصفحات بنسبة تحددها؛ لا يحذف المحتوى المخفي نهائيًا.",watermarkPdf:"أضف علامة مائية على صفحات الملف.",numberPdf:"أضف أرقامًا للصفحات.",pdfPowerpoint:"كل صفحة شريحة كصورة، مع الحفاظ على شكل الملف.",pdfMarkdown:"استخرج النص المضمّن في ملف Markdown، دون استعادة تنسيق المستند."})[item[0]] : "قيد التطوير"])}));
const tools = categories.flatMap((category) =>
  category.tools.filter((tool) => Array.isArray(tool)),
);

export class AppUI {
  constructor() {
    this.busy = false;
    this.cancelled = false;
    this.downloadUrl = "";
    this.ranges = [];
    this.draggedPageId = null;

    this.history = new HistoryManager(() => this.updateUndoButtons());
    this.files = new FileManager();
    this.pages = new PageManager(this.history);
    this.preview = new PreviewManager({
      modal: $("#modal"),
      canvas: $("#previewCanvas"),
      title: $("#modalTitle"),
    });
    this.exporter = new ExportManager(this);

    this.bindEvents();
    this.renderTools();
    this.simplifyWorkspace();
    this.loadTheme();
    this.updateCounts();
    this.updateOperation();
  }

  simplifyWorkspace() {
    // Keep one task per workspace; the home library is the task switcher.
    $("#operation").closest(".field").hidden = true;
    const toolbar = $("#selectAll").closest(".toolbar");
    const extra = document.createElement("details");
    extra.className = "extra-page-tools";
    const summary = document.createElement("summary");
    summary.textContent = "خيارات الصفحات المتقدمة";
    const body = document.createElement("div"); body.className = "toolbar";
    ["selectOdd", "selectEven", "invert", "reverse", "duplicate", "blank"].forEach(id => body.append($("#" + id)));
    extra.append(summary, body);
    toolbar.after(extra);
    const search = $("#textSearch").closest(".toolbar");
    const searchDetails = document.createElement("details"); searchDetails.className = "extra-page-tools";
    const searchSummary = document.createElement("summary"); searchSummary.textContent = "البحث داخل الملف";
    search.before(searchDetails); searchDetails.append(searchSummary, search);
    [["undo", "↶", "تراجع (Ctrl+Z)"], ["redo", "↷", "إعادة (Ctrl+Y)"]].forEach(([id, icon, label]) => {
      const button = $("#"+id); button.textContent = icon; button.title = label; button.setAttribute("aria-label", label); button.classList.add("history-arrow");
    });
    $("#selectNone").textContent = "إلغاء التحديد";
    $("#selectAll").textContent = "تحديد الكل";
    $("#rotate").textContent = "تدوير المحدد";
    const info = document.createElement("details"); info.className = "extra-page-tools";
    const infoSummary = document.createElement("summary"); infoSummary.textContent = "تفاصيل الملف وسجل التنزيل";
    const infoTitle = $("#fileInfo").previousElementSibling;
    const historyTitle = $("#history").previousElementSibling;
    infoTitle.before(info); info.append(infoSummary, infoTitle, $("#fileInfo"), historyTitle, $("#history"));
    const hints = document.createElement("p"); hints.className = "task-hint"; hints.id = "taskHint";
    $("#toolDesc").after(hints);
  }

  safeName(value) {
    return (
      String(value || "ملفي")
        .replace(/\.(pdf|zip|txt|doc)$/i, "")
        .replace(/[<>:"/\\|?*\u0000-\u001f]/g, "")
        .trim() || "ملفي"
    );
  }

  number(value) {
    return new Intl.NumberFormat("ar-SA").format(value);
  }

  bindEvents() {
    $("#tools").addEventListener("click", (event) => {
      const button = event.target.closest("[data-tool]");
      if (button) this.openTool(button.dataset.tool);
    });

    $("#homeLink").addEventListener("click", (event) => {
      event.preventDefault();
      this.goHome();
    });

    $("#backBtn").addEventListener("click", () => this.goHome());

    $("#fileInput").addEventListener("change", async (event) => {
      await this.addFiles(event.target.files);
      event.target.value = "";
    });

    this.bindDropzone();

    $("#fileList").addEventListener("click", (event) =>
      this.onFileClick(event),
    );

    $("#pageGrid").addEventListener("click", (event) =>
      this.onPageClick(event),
    );

    $("#pageGrid").addEventListener("change", (event) =>
      this.onPageChange(event),
    );

    this.bindPageDragging();

    $("#selectAll").onclick = () =>
      this.pageAction(() => this.pages.selectAll());

    $("#selectNone").onclick = () =>
      this.pageAction(() => this.pages.selectNone());

    $("#selectOdd").onclick = () =>
      this.pageAction(() => this.pages.selectOdd());

    $("#selectEven").onclick = () =>
      this.pageAction(() => this.pages.selectEven());

    $("#invert").onclick = () =>
      this.pageAction(() => this.pages.invertSelection());

    $("#reverse").onclick = () => this.pageAction(() => this.pages.reverse());

    $("#duplicate").onclick = () =>
      this.pageAction(() => this.pages.duplicateSelected());

    $("#blank").onclick = () => this.pageAction(() => this.pages.addBlank());

    $("#rotate").onclick = () => this.rotateSelected();

    $("#undo").onclick = () => {
      this.pages.undo();
      this.renderAll();
    };

    $("#redo").onclick = () => {
      this.pages.redo();
      this.renderAll();
    };

    $("#operation").addEventListener("change", () => this.updateOperation());
    $("#fromPage").addEventListener("change", () => this.fixRangeSelects());
    $("#addRange").onclick = () => this.addRange();

    $("#clearRanges").onclick = () => {
      this.ranges = [];
      this.renderRanges();
    };

    $("#rangeList").addEventListener("click", (event) =>
      this.removeRange(event),
    );

    $("#searchBtn").onclick = () => this.searchText();
    $("#runBtn").onclick = () => this.runExport();

    $("#cancelBtn").onclick = () => {
      this.cancelled = true;
    };

    $("#closeModal").onclick = () => this.preview.close();
    $("#previewPrev").onclick = () => this.preview.move(-1);
    $("#previewNext").onclick = () => this.preview.move(1);
    $("#themeBtn").onclick = () => this.toggleTheme();

    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") this.preview.close();

      if (!$("#modal").hidden && event.key === "ArrowLeft") {
        this.preview.move(1);
      }

      if (!$("#modal").hidden && event.key === "ArrowRight") {
        this.preview.move(-1);
      }

      if (event.target.matches("input,select,textarea")) return;

      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "z") {
        event.preventDefault();
        this.pages.undo();
        this.renderAll();
      }

      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "y") {
        event.preventDefault();
        this.pages.redo();
        this.renderAll();
      }
    });
  }

  bindDropzone() {
    const drop = $("#drop");

    ["dragenter", "dragover"].forEach((type) => {
      drop.addEventListener(type, (event) => {
        event.preventDefault();
        drop.classList.add("over");
      });
    });

    ["dragleave", "drop"].forEach((type) => {
      drop.addEventListener(type, (event) => {
        event.preventDefault();
        drop.classList.remove("over");
      });
    });

    drop.addEventListener("drop", (event) =>
      this.addFiles(event.dataTransfer.files),
    );
  }

  bindPageDragging() {
    const grid = $("#pageGrid");

    grid.addEventListener("dragstart", (event) => {
      const card = event.target.closest("[data-page]");
      if (!card) return;

      this.draggedPageId = card.dataset.page;
      card.classList.add("dragging");

      if (event.dataTransfer) {
        event.dataTransfer.effectAllowed = "move";
        event.dataTransfer.setData("text/plain", this.draggedPageId);
      }
    });

    grid.addEventListener("dragover", (event) => {
      const target = event.target.closest("[data-page]");

      if (!target || target.dataset.page === this.draggedPageId) return;

      event.preventDefault();
      target.classList.add("drop-target");
    });

    grid.addEventListener("dragleave", (event) => {
      event.target.closest("[data-page]")?.classList.remove("drop-target");
    });

    grid.addEventListener("drop", (event) => {
      event.preventDefault();

      const target = event.target.closest("[data-page]");
      const draggedId =
        this.draggedPageId || event.dataTransfer?.getData("text/plain");

      if (target && draggedId) {
        this.pages.moveBefore(draggedId, target.dataset.page);
        this.renderAll();
      }

      this.clearDragStyles();
    });

    grid.addEventListener("dragend", () => this.clearDragStyles());
  }

  clearDragStyles() {
    $("#pageGrid")
      .querySelectorAll(".dragging,.drop-target")
      .forEach((card) => {
        card.classList.remove("dragging", "drop-target");
      });

    this.draggedPageId = null;
  }

  renderTools() {
    this.activeCategory = "all";
    const tabs = document.querySelector(".filter-tabs");
    [["conversion", "التحويل"], ["quick-tools", "إنجاز سريع"], ...templateGroups.map(group => [group[0], group[1]])].forEach(([id, title]) => {
      const button = document.createElement("button"); button.className = "filter-tab"; button.dataset.category = id; button.textContent = title; button.setAttribute("aria-pressed", "false"); tabs.append(button);
    });
    $("#tools").innerHTML = categories.filter(category => category.tools.some(Array.isArray)).map(category =>       category.tools.filter(Array.isArray).map((tool) => `
        <button class="tool ${tool[0] === 'merge' ? 'featured' : ''}" ${templateIds.has(tool[0]) ? 'disabled aria-disabled="true" title="قالب فقط — لم تُبرمج هذه الأداة بعد"' : ""} data-tool="${tool[0]}" data-group="${category.id}" type="button">
          <span class="tool-top"><span class="tool-icon">${toolIcon(tool[0])}</span><span class="tool-format">${tool[0] === 'merge' ? 'ابدأ من هنا' : tool[1]}</span></span>
          <span class="tool-copy"><strong>${tool[2]}</strong><small>${tool[3]}</small></span>
          <span class="tool-bottom"><span>${category.title}</span><span class="tool-arrow" aria-hidden="true">↖</span></span>
        </button>`).join("")
    ).join("");
    $("#toolTotal").textContent = this.number(tools.length) + " أداة وقالب";
    const countBadge = document.querySelector('[data-category="all"] span');
    if (countBadge) countBadge.textContent = this.number(tools.length);
    $("#toolSearch").addEventListener("input", () => this.filterTools());
    document.querySelectorAll("[data-category]").forEach(button => button.addEventListener("click", () => {
      this.activeCategory = button.dataset.category;
      this.filterTools();
    }));
    $("#clearSearch").addEventListener("click", () => {
      $("#toolSearch").value = "";
      this.activeCategory = "all";
      this.filterTools();
      $("#toolSearch").focus();
    });
    document.addEventListener("keydown", event => {
      if (event.key === "/" && !event.target.matches("input,select,textarea") && !$("#home").hidden) {
        event.preventDefault(); $("#toolSearch").focus();
      }
    });
  }

  filterTools() {
    const query = this.normalizeText($("#toolSearch").value);
    let count = 0;
    document.querySelectorAll("#tools [data-tool]").forEach(card => {
      const matches = (this.activeCategory === "all" || card.dataset.group === this.activeCategory || (this.activeCategory === "conversion" && ["images", "imagesPng", "imagesWebp", "imagesPdf", "text", "ocr"].includes(card.dataset.tool))) && this.normalizeText(card.textContent).includes(query);
      card.hidden = !matches;
      if (matches) count++;
    });
    document.querySelectorAll("[data-category]").forEach(button => {
      const active = button.dataset.category === this.activeCategory;
      button.classList.toggle("active", active);
      button.setAttribute("aria-pressed", String(active));
    });
    $("#toolTotal").textContent = this.number(count) + " أداة وقالب";
    $("#emptyTools").hidden = count !== 0;
  }

  openTool(id) {
    if (this.busy || this.loadingFiles || templateIds.has(id)) return;
    this.reset();
    $("#home").hidden = true;
    $("#work").hidden = false;

    const tool = tools.find((item) => item[0] === id);
    if (!tool) return;

    $("#toolTitle").textContent = tool[2];
    $("#toolDesc").textContent = tool[3];
    $("#operation").value = id === "rotate" ? "merge" : id;
    $("#outputName").value = this.safeName(tool[2]);
    $("#numberPages").checked = id === "numberPdf";
    $("#watermark").value = "";
    const advanced = document.querySelector(".advanced-settings");
    if (advanced) advanced.open = id === "watermarkPdf" || id === "numberPdf";
    this.updateOperation();
  }

  goHome() {
    if (this.busy) return;
    this.reset();
    $("#work").hidden = true;
    $("#home").hidden = false;
  }

  reset() {
    this.files.clear();
    this.pages.clear();
    this.ranges = [];
    this.cancelled = false;

    $("#fileInput").value = "";
    $("#fileList").innerHTML = "";
    $("#pageGrid").innerHTML = "";
    $("#rangeList").innerHTML = "";
    $("#history").innerHTML = "";
    $("#searchStatus").textContent = "";
    $("#progress").hidden = true;
    $("#result").hidden = true;
    $("#error").hidden = true;
    $("#pageArea").hidden = true;

    if (this.downloadUrl) {
      URL.revokeObjectURL(this.downloadUrl);
      this.downloadUrl = "";
    }

    this.renderRangeSelects();
    this.updateCounts();
  }

  async addFiles(fileList) {
    if (this.busy || this.loadingFiles) return;
    this.loadingFiles = true;
    this.clearError();

    try {
      if ($("#operation").value === "imagesPdf") {
        this.files.addImages(fileList);
        $("#outputName").value = "صور-إلى-PDF";
      } else {
        const added = await this.files.addPdfs(fileList);
        added.forEach((file) => this.pages.addFile(file));

        $("#outputName").value =
          this.files.files.length === 1
            ? this.safeName(this.files.files[0].name)
            : "ملف-مدمج";
      }

      this.renderAll();
      await this.renderThumbnails();
    } catch (error) {
      this.showError(error.message);
    } finally { this.loadingFiles = false; this.updateOperation(); }
  }

  async renderThumbnails() {
    for (const page of this.pages.pages) {
      if (page.thumbnail) continue;

      try {
        const canvas = await this.exporter.renderPage(page, 0.23);
        page.thumbnail = canvas.toDataURL("image/jpeg", 0.62);
        canvas.width = 0;
      } catch (error) {
        console.warn("تعذرت معاينة الصفحة:", error);
      }
    }

    this.renderPages();
  }

  onFileClick(event) {
    const remove = event.target.closest("[data-remove-file]");
    const up = event.target.closest("[data-up-file]");
    const down = event.target.closest("[data-down-file]");

    if (remove) {
      this.files.remove(remove.dataset.removeFile);
      this.pages.removeFile(remove.dataset.removeFile);
      this.history.undoStack = [];
      this.history.redoStack = [];
      this.ranges = [];
      this.renderAll();
      return;
    }

    const button = up || down;
    if (!button) return;

    const id = button.dataset.upFile || button.dataset.downFile;

    if (this.files.move(id, up ? -1 : 1)) {
      this.pages.reorderFiles(this.files.files);
      this.ranges = [];
      this.renderAll();
    }
  }

  async onPageClick(event) {
    const previewButton = event.target.closest("[data-preview]");

    if (previewButton) {
      const page = this.pages.pages.find(
        (item) => item.id === previewButton.dataset.preview,
      );

      if (page) await this.preview.open(page);
      return;
    }

    const remove = event.target.closest("[data-remove-page]");
    const up = event.target.closest("[data-up-page]");
    const down = event.target.closest("[data-down-page]");
    const rotate = event.target.closest("[data-rotate-page]");

    try {
      if (remove) this.pages.removePage(remove.dataset.removePage);
      if (up) this.pages.movePage(up.dataset.upPage, -1);
      if (down) this.pages.movePage(down.dataset.downPage, 1);

      if (rotate) {
        this.pages.rotatePage(rotate.dataset.rotatePage);
      }

      this.clearError();
      this.renderPages();

      if (rotate) await this.renderThumbnails();
    } catch (error) {
      this.showError(error.message);
    }
  }

  onPageChange(event) {
    const checkbox = event.target.closest("[data-check-page]");
    if (!checkbox) return;

    this.pages.toggleSelection(checkbox.dataset.checkPage, checkbox.checked);
    this.renderAll();
  }

  pageAction(action) {
    try {
      action();
      this.clearError();
      this.renderAll();
    } catch (error) {
      this.showError(error.message);
    }
  }

  async rotateSelected() {
    try {
      this.pages.rotateSelected();
      this.renderPages();
      await this.renderThumbnails();
    } catch (error) {
      this.showError(error.message);
    }
  }

  addRange() {
    const from = Number($("#fromPage").value);
    const to = Number($("#toPage").value);

    if (!from || !to || to < from) {
      this.showError("اختر بداية ونهاية صحيحتين.");
      return;
    }

    this.ranges.push({ from, to });
    this.renderRanges();
    this.clearError();
  }

  removeRange(event) {
    const button = event.target.closest("[data-range-remove]");
    if (!button) return;

    this.ranges.splice(Number(button.dataset.rangeRemove), 1);
    this.renderRanges();
  }

  fixRangeSelects() {
    const from = Number($("#fromPage").value);
    const to = Number($("#toPage").value);

    if (from && to < from) {
      $("#toPage").value = String(from);
    }
  }

  renderRangeSelects() {
    const fromSelect = $("#fromPage");
    const toSelect = $("#toPage");

    if (!this.pages.pages.filter(page => !page.deleted).length) {
      const empty = '<option value="">أضف PDF أولًا</option>';
      fromSelect.innerHTML = empty;
      toSelect.innerHTML = empty;
      fromSelect.disabled = true;
      toSelect.disabled = true;
      $("#addRange").disabled = true;
      return;
    }

    const oldFrom = Number(fromSelect.value) || 1;
    const oldTo = Number(toSelect.value) || this.pages.pages.filter(page => !page.deleted).length;

    const options = this.pages.pages.filter(page => !page.deleted)
      .map(
        (page, index) => `
          <option value="${index + 1}">
            صفحة ${this.number(index + 1)}${page.blank ? " (فارغة)" : ""}
          </option>
        `,
      )
      .join("");

    fromSelect.innerHTML = options;
    toSelect.innerHTML = options;
    fromSelect.disabled = false;
    toSelect.disabled = false;
    fromSelect.value = String(Math.min(oldFrom, this.pages.pages.filter(page => !page.deleted).length));
    toSelect.value = String(
      Math.max(
        Number(fromSelect.value),
        Math.min(oldTo, this.pages.pages.filter(page => !page.deleted).length),
      ),
    );
    $("#addRange").disabled = false;
  }

  renderRanges() {
    $("#rangeList").innerHTML = this.ranges
      .map(
        (range, index) => `
          <div class="range-item">
            <span>
              النطاق ${this.number(index + 1)}:
              من ${this.number(range.from)} إلى ${this.number(range.to)}
            </span>
            <button
              class="btn danger small"
              data-range-remove="${index}"
              type="button"
            >×</button>
          </div>
        `,
      )
      .join("");

    $("#clearRanges").disabled = this.ranges.length === 0;
  }

  renderFiles() {
    $("#fileList").innerHTML = this.files.files
      .map(
        (file) => `
          <div class="file-row">
            <span class="file-icon">${file.kind === "image" ? "IMG" : "PDF"}</span>
            <span class="file-info">
              <span class="file-name" title="${this.escapeHtml(file.name)}">
                ${this.escapeHtml(file.name)}
              </span>
              <span class="muted">
                ${file.pdf ? `${this.number(file.pdf.numPages)} صفحة · ` : ""}
                ${(file.size / 1048576).toFixed(2)} MB
              </span>
            </span>
            <span class="file-actions">
              ${
                this.files.files.length > 1
                  ? `
                    <button class="btn small" data-up-file="${file.id}" type="button">↑</button>
                    <button class="btn small" data-down-file="${file.id}" type="button">↓</button>
                  `
                  : ""
              }
              <button
                class="btn danger small"
                aria-label="إزالة الملف ${this.escapeHtml(file.name)}"
                data-remove-file="${file.id}"
                type="button"
              >×</button>
            </span>
          </div>
        `,
      )
      .join("");
  }

  renderPages() {
    const pages = this.pages.pages;
    let outputPosition = 0;

    $("#pageGrid").innerHTML = pages
      .map(
        (page, index) => { const position = page.deleted ? null : ++outputPosition; return `
          <article
            class="page ${page.deleted ? "deleted" : page.selected ? "" : "off"}"
            data-page="${page.id}"
            draggable="${!page.deleted}"
          >
            <img
              class="thumb"
              data-preview="${page.id}"
              alt="معاينة الصفحة ${index + 1}"
              src="${page.thumbnail || ""}"
            >
            <label class="page-label">
              <input
                type="checkbox"
                data-check-page="${page.id}"
                ${page.selected ? "checked" : ""} ${page.deleted ? "disabled" : ""}
              >
              <span class="page-origin">${page.blank ? "صفحة فارغة" : "الأصل " + this.number(page.number)} <span aria-hidden="true">←</span> ${page.deleted ? "محذوفة" : "الآن " + this.number(position)}</span>
              ${!page.blank && !page.deleted && page.manuallyMoved ? '<span class="moved-tag">تغيّر موقعها</span>' : ""}
            </label>
            <span class="source-file" title="${this.escapeHtml(page.fileName)}">${this.escapeHtml(page.fileName)}</span>
            <div class="page-actions ${page.deleted ? 'restore-actions' : ''}">
              <button class="btn small" data-up-page="${page.id}" type="button" title="تحريك للأعلى">↑</button>
              <button class="btn small" data-down-page="${page.id}" type="button" title="تحريك للأسفل">↓</button>
              <button class="btn small" data-rotate-page="${page.id}" type="button" title="تدوير">↻</button>
              <button class="btn danger small" data-remove-page="${page.id}" type="button" aria-label="${page.deleted ? 'استعادة الصفحة' : 'حذف الصفحة'}" title="${page.deleted ? 'استعادة' : 'حذف'}">${page.deleted ? 'استعادة' : '×'}</button>
            </div>
          </article>
        `; },
      )
      .join("");

    $("#pageArea").hidden = pages.length === 0;
    this.preview.setPages(pages);
    this.renderRangeSelects();
    this.updateCounts();
  }

  renderAll() {
    this.renderFiles();
    this.renderPages();
    this.renderRanges();
    this.updateCounts();
    this.updateOperation();
  }

  updateCounts() {
    const files = this.files.files;
    const pages = this.pages.pages;
    const selected = pages.filter((page) => page.selected && !page.deleted).length;

    $("#counts").textContent = files.length
      ? `${this.number(files.length)} ملف · ${this.number(pages.filter(page => !page.deleted).length)} صفحة · ${this.number(pages.filter(page => page.deleted).length)} محذوفة`
      : "لا توجد ملفات";

    $("#drop").classList.toggle("has-files", files.length > 0);
    $("#fileInfo").textContent = files.length
      ? `${this.number(files.length)} ملف · ${this.number(pages.length)} صفحة · ${this.number(selected)} محددة · ${(this.files.totalSize / 1048576).toFixed(2)} MB`
      : "لم تتم إضافة ملفات.";

    $("#runBtn").disabled = !files.length || this.busy || ( $("#operation").value !== "imagesPdf" && !pages.length );
    this.updateUndoButtons();
  }

  updateUndoButtons() {
    const undo = $("#undo");
    const redo = $("#redo");

    if (!undo || !redo) return;

    undo.disabled = !this.history.canUndo();
    redo.disabled = !this.history.canRedo();
  }

  updateOperation() {
    const operation = $("#operation").value;

    $("#rangesPanel").hidden = operation !== "splitRanges";
    $("#ocrField").hidden = operation !== "ocr";
    $("#imageSizeField").hidden = operation !== "imagesPdf";
    $("#cropOptions").hidden = operation !== "cropPdf";
    $("#qualityField").hidden = !["compress", "images", "imagesPng", "imagesWebp"].includes(operation);

    const labels = {
      reversePdf: "تنزيل بالترتيب المعكوس", oddPdf: "تنزيل الصفحات الفردية", evenPdf: "تنزيل الصفحات الزوجية", splitHalf: "تنزيل الجزأين ZIP",
      merge: "دمج وتصدير PDF",
      extract: "تصدير الصفحات المحددة",
      delete: "تصدير دون الصفحات المحددة",
      splitRanges: "تقسيم النطاقات إلى ZIP",
      splitEach: "تقسيم كل صفحة إلى ZIP",
      compress: "ضغط PDF",
      pdfWord: "تنزيل Word", comparePdf: "تنزيل تقرير المقارنة", cropPdf: "قص وتنزيل PDF",
      pdfPowerpoint: "تنزيل PowerPoint",
      watermarkPdf: "إضافة العلامة وتنزيل PDF", numberPdf: "ترقيم وتنزيل PDF", pdfMarkdown: "تنزيل Markdown",
      imagesPng: "تنزيل صور PNG",
      imagesWebp: "تنزيل صور WebP",
      images: "تنزيل صور JPG",
      imagesPdf: "تحويل الصور إلى PDF",
      text: "استخراج TXT",
      ocr: "OCR إلى Word",
      repair: "إعادة حفظ PDF",
    };

    $("#runBtn").textContent = this.files.files.length ? (labels[operation] || "تجهيز وتنزيل") : "أضف ملفك أولًا";

    const imageMode = operation === "imagesPdf";

    $("#fileInput").accept = imageMode
      ? "image/jpeg,image/png"
      : ".pdf,application/pdf";

    $("#pickLabel").textContent = imageMode
      ? "اختيار صور JPG/PNG"
      : "اختيار ملفات PDF";

    $("#dropTitle").textContent = imageMode
      ? "اسحب صور JPG أو PNG هنا"
      : "اسحب ملفات PDF هنا";

    $("#dropHint").textContent = imageMode
      ? "يمكن إضافة عدة صور."
      : "أضف ملفات PDF ثم رتّب الصفحات.";

    const wrongFiles = this.files.files.some(
      (file) => (file.kind === "image") !== imageMode,
    );

    if (wrongFiles) {
      this.showError(
        "نوع الملفات الحالية لا يناسب العملية المختارة. أزل الملفات أو ابدأ من الأداة المناسبة.",
      );
      $("#runBtn").disabled = true;
    } else {
      this.clearError();
      $("#runBtn").disabled = !this.files.files.length || this.busy || this.loadingFiles;
    }
  }

  async searchText() {
    const query = this.normalizeText($("#textSearch").value);

    if (!query) {
      this.showError("اكتب كلمة للبحث.");
      return;
    }

    const hits = [];

    try {
      for (let index = 0; index < this.pages.pages.length; index++) {
        const page = this.pages.pages[index];

        if (!page.blank) {
          const pdfPage = await page.pdf.getPage(page.number);
          const content = await pdfPage.getTextContent();
          const text = this.normalizeText(
            content.items.map((item) => item.str).join(" "),
          );

          if (text.includes(query)) hits.push(page);
        }

        $("#searchStatus").textContent =
          `فحص ${this.number(index + 1)} من ${this.number(this.pages.pages.length)}`;
      }

      if (!hits.length) {
        $("#searchStatus").textContent =
          "لا توجد مطابقة؛ الصفحات المصورة تحتاج OCR.";
        return;
      }

      const ids = new Set(hits.map((page) => page.id));
      this.pages.select((page) => ids.has(page.id));
      this.renderAll();

      $("#searchStatus").textContent =
        `تم تحديد ${this.number(hits.length)} صفحة مطابقة.`;
    } catch {
      this.showError("تعذّر البحث داخل هذا الملف.");
    }
  }

  normalizeText(value) {
    return String(value)
      .normalize("NFKC")
      .replace(/[\u064B-\u065F\u0670\u0640]/g, "")
      .replace(/[إأآٱ]/g, "ا")
      .replace(/ى/g, "ي")
      .toLowerCase()
      .trim();
  }

  async runExport() {
    if (this.busy || this.loadingFiles || !this.files.files.length) return;

    this.clearError();
    this.cancelled = false;
    this.busy = true;
    const lockedControls = Array.from(document.querySelectorAll("#work button, #work input, #work select")).map(element => ({element, disabled:element.disabled}));
    lockedControls.forEach(({element}) => {element.disabled = true;});
    $("#cancelBtn").disabled = false;
    $("#runBtn").disabled = true;
    $("#cancelBtn").hidden = false;
    $("#result").hidden = true;

    try {
      const output = await this.exporter.export(
        $("#operation").value,
        this.pages.pages.filter(page => !page.deleted),
        this.ranges,
      );

      if (!this.cancelled) {
        this.progress(100, "اكتملت العملية", "تم تجهيز الملف للتنزيل.");
        this.showResult(output, $("#operation option:checked").textContent);
      }
    } catch (error) {
      if (this.cancelled) {
        this.progress(0, "أُلغيت العملية", "");
      } else {
        this.showError(error.message || "تعذرت العملية.");
        $("#progress").hidden = true;
      }
    } finally {
      this.busy = false;
      lockedControls.forEach(({element,disabled}) => {element.disabled = disabled;});
      $("#cancelBtn").hidden = true;
      this.updateCounts();
    }
  }

  progress(percent, title, status) {
    $("#progress").hidden = false;
    $("#progressFill").style.width = `${Math.max(0, Math.min(100, percent))}%`;
    $("#progressPct").textContent = `${this.number(Math.round(percent))}٪`;
    $("#progressTitle").textContent = title;
    $("#progressStatus").textContent = status || "";
  }

  showResult(output, label) {
    $("#result").hidden = false;
    $("#result").replaceChildren();

    const title = document.createElement("strong");
    title.textContent = `اكتملت: ${label}`;

    const size = document.createElement("div");
    size.textContent = `حجم الناتج: ${(output.size / 1048576).toFixed(2)} MB`;

    $("#result").append(title, size);

    if (this.downloadUrl) URL.revokeObjectURL(this.downloadUrl);

    this.downloadUrl = URL.createObjectURL(output.blob);

    const link = document.createElement("a");
    link.href = this.downloadUrl;
    link.download = output.name;
    link.textContent = "تنزيل الناتج";
    $("#result").append(link);
    link.click();

    const historyItem = document.createElement("div");
    historyItem.className = "history-item";
    historyItem.textContent = `${new Date().toLocaleTimeString("ar-SA")} — ${label}`;

    $("#history").prepend(historyItem);
  }

  showError(message) {
    $("#error").textContent = message;
    $("#error").hidden = false;
  }

  clearError() {
    $("#error").textContent = "";
    $("#error").hidden = true;
  }

  escapeHtml(value) {
    return String(value)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;");
  }

  toggleTheme() {
    document.body.classList.toggle("dark");
    const dark = document.body.classList.contains("dark");

    try {
      localStorage.setItem("masaha-dark", dark ? "1" : "0");
    } catch {}

    $("#themeBtn").textContent = dark ? "الوضع الفاتح" : "الوضع الداكن";
    $("#themeBtn").setAttribute("aria-pressed", String(dark));
  }

  loadTheme() {
    $("#themeBtn").setAttribute("aria-pressed", "false");
    try {
      if (localStorage.getItem("masaha-dark") === "1") {
        document.body.classList.add("dark");
        $("#themeBtn").textContent = "الوضع الفاتح";
        $("#themeBtn").setAttribute("aria-pressed", "true");
      }
    } catch {}
  }
}
