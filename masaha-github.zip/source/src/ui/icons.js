const paths = {
  merge: '<path d="M8 3H3v14h5M16 7h5v14h-5M8 7h8v14H8zM11 3h5v4"/>',
  splitRanges: '<path d="M7 3h10v7M7 14v7h10v-7M3 12h18M5 9l-3 3 3 3m14-6 3 3-3 3"/>',
  splitEach: '<rect x="3" y="3" width="7" height="8"/><rect x="14" y="13" width="7" height="8"/><path d="M14 3h7v6M3 15v6h7M12 7h5m-2-2 2 2-2 2M12 17H7m2-2-2 2 2 2"/>',
  extract: '<path d="M12 3H4v18h16v-8M14 3h7v7M21 3l-10 10"/>',
  delete: '<path d="M6 3h8l4 4v14H6zM14 3v5h4M9 13h6"/>',
  compress: '<path d="M4 8V3h5M20 16v5h-5M4 3l6 6m0-5v5H5M20 21l-6-6m0 5v-5h5"/>',
  rotate: '<path d="M4 11a8 8 0 1 1 2 7M4 5v6h6"/><rect x="10" y="9" width="6" height="8"/>',
  repair: '<path d="M7 3h9l4 4v14H7M16 3v5h4M3 12h10m-4-4 4 4-4 4"/>',
  images: '<rect x="3" y="3" width="18" height="18"/><circle cx="8" cy="8" r="1.5"/><path d="m3 17 6-6 4 4 3-3 5 5"/>',
  imagesPdf: '<path d="M4 3h12v5M4 3v14h5M9 8h11v13H9zM12 12h5m-5 4h5"/>',
  text: '<path d="M4 7V4h16v3M12 4v16m-4 0h8"/>',
  ocr: '<path d="M3 8V3h5m8 0h5v5M3 16v5h5m8 0h5v-5M7 16l5-9 5 9m-8-3h6"/>',
};
export function toolIcon(id) {
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="square" stroke-linejoin="miter" aria-hidden="true">${paths[id] || paths.merge}</svg>`;
}
