import { AppUI } from "./ui/AppUI.js";

if (globalThis.pdfjsLib) {
  pdfjsLib.GlobalWorkerOptions.workerSrc =
    "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";
}

const app = new AppUI();
window.masahaApp = app;
