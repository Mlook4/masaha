function makeId() {
  return (
    globalThis.crypto?.randomUUID?.() ??
    `${Date.now()}-${Math.random().toString(16).slice(2)}`
  );
}

export class PageManager {
  constructor(history) {
    this.pages = [];
    this.history = history;
  }

  save() {
    this.history.save(this.pages);
  }

  addFile(file) {
    for (let number = 1; number <= file.pdf.numPages; number++) {
      this.pages.push({
        id: makeId(),
        file,
        fileName: file.name,
        pdf: file.pdf,
        number,
        rotation: 0,
        selected: true,
        blank: false,
        thumbnail: "",
      });
    }
  }

  addBlank() {
    this.save();
    this.pages.push({
      id: makeId(),
      file: null,
      fileName: "صفحة فارغة",
      pdf: null,
      number: 0,
      rotation: 0,
      selected: true,
      blank: true,
      thumbnail: "",
    });
  }

  select(callback) {
    if (!this.pages.length) return;
    this.save();
    this.pages.forEach((page, index) => {
      page.selected = Boolean(callback(page, index));
    });
  }

  selectAll() {
    this.select(() => true);
  }
  selectNone() {
    this.select(() => false);
  }
  selectOdd() {
    this.select((page, index) => index % 2 === 0);
  }
  selectEven() {
    this.select((page, index) => index % 2 === 1);
  }
  invertSelection() {
    this.select((page) => !page.selected);
  }

  toggleSelection(id, checked) {
    const page = this.pages.find((item) => item.id === id);
    if (!page) return;
    this.save();
    page.selected = Boolean(checked);
  }

  removePage(id) {
    const page = this.pages.find(item => item.id === id);
    if (!page) return;
    if (!page.deleted && this.pages.filter(item => !item.deleted).length <= 1) throw new Error("اترك صفحة واحدة على الأقل.");
    this.save(); page.deleted = !page.deleted;
  }

  removeFile(fileId) {
    this.pages = this.pages.filter((page) => page.file?.id !== fileId);
  }

  movePage(id, direction) {
    const index = this.pages.findIndex((page) => page.id === id);
    const target = index + direction;

    if (index < 0 || target < 0 || target >= this.pages.length) return false;

    this.save();
    [this.pages[index], this.pages[target]] = [
      this.pages[target],
      this.pages[index],
    ];

    this.pages[index].manuallyMoved = true;
    this.pages[target].manuallyMoved = true;
    return true;
  }

  moveBefore(draggedId, targetId) {
    if (draggedId === targetId) return false;

    const fromIndex = this.pages.findIndex((page) => page.id === draggedId);
    if (fromIndex < 0 || !this.pages.some((page) => page.id === targetId))
      return false;

    this.save();

    const [page] = this.pages.splice(fromIndex, 1);
    const targetIndex = this.pages.findIndex((item) => item.id === targetId);
    this.pages.splice(targetIndex, 0, page);
    page.manuallyMoved = true;

    return true;
  }

  reverse() {
    if (this.pages.length < 2) return;
    this.save();
    this.pages.reverse();
    this.pages.forEach(page => { if (!page.deleted) page.manuallyMoved = true; });
  }

  rotatePage(id) {
    const page = this.pages.find((item) => item.id === id);
    if (!page) return;

    this.save();
    page.rotation = (page.rotation + 90) % 360;
    page.thumbnail = "";
  }

  rotateSelected() {
    const selected = this.pages.filter((page) => page.selected && !page.deleted);
    if (!selected.length) throw new Error("حدد صفحات أولًا.");

    this.save();
    selected.forEach((page) => {
      page.rotation = (page.rotation + 90) % 360;
      page.thumbnail = "";
    });
  }

  duplicateSelected() {
    const indexes = this.pages
      .map((page, index) => (page.selected && !page.deleted ? index : -1))
      .filter((index) => index >= 0);

    if (!indexes.length) throw new Error("حدد صفحات تريد تكرارها أولًا.");

    this.save();

    let offset = 0;
    for (const index of indexes) {
      const copy = {
        ...this.pages[index + offset],
        id: makeId(),
        selected: true,
      };

      this.pages.splice(index + offset + 1, 0, copy);
      offset++;
    }
  }

  reorderFiles(files) {
    const order = new Map(files.map((file, index) => [file.id, index]));

    this.pages.sort(
      (a, b) =>
        (order.get(a.file?.id) ?? Number.MAX_SAFE_INTEGER) -
          (order.get(b.file?.id) ?? Number.MAX_SAFE_INTEGER) ||
        a.number - b.number,
    );
  }

  undo() {
    const previous = this.history.undo(this.pages);
    if (previous) this.pages = previous;
  }

  redo() {
    const next = this.history.redo(this.pages);
    if (next) this.pages = next;
  }

  clear() {
    this.pages = [];
    this.history.clear();
  }
}
