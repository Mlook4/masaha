function makeId() {
  return (
    globalThis.crypto?.randomUUID?.() ??
    `${Date.now()}-${Math.random().toString(16).slice(2)}`
  );
}

export class FileManager {
  constructor() {
    this.files = [];
    this.maxFileSize = 150 * 1024 * 1024;
    this.maxTotalSize = 350 * 1024 * 1024;
    this.maxPages = 1000;
  }

  get totalSize() {
    return this.files.reduce((sum, file) => sum + file.size, 0);
  }

  async addPdfs(fileList) {
    if (!globalThis.pdfjsLib) {
      throw new Error("مكتبة PDF.js لم تُحمّل. تحقق من اتصال الإنترنت.");
    }

    const added = [];

    for (const rawFile of Array.from(fileList)) {
      const isPdf =
        rawFile.type === "application/pdf" ||
        rawFile.name.toLowerCase().endsWith(".pdf");

      if (!isPdf) continue;
      if (rawFile.size > this.maxFileSize) {
        throw new Error(`${rawFile.name} أكبر من الحد المسموح 150 MB.`);
      }
      if (this.totalSize + added.reduce((sum, file) => sum + file.size, 0) + rawFile.size > this.maxTotalSize) {
        throw new Error("الحجم الإجمالي للملفات يتجاوز 350 MB.");
      }

      const bytes = new Uint8Array(await rawFile.arrayBuffer());
      const pdf = await pdfjsLib.getDocument({ data: bytes.slice() }).promise;

      if (pdf.numPages > this.maxPages) {
        throw new Error(`${rawFile.name} يتجاوز الحد المدعوم وهو 1000 صفحة.`);
      }

      const file = {
        id: makeId(),
        name: rawFile.name,
        size: rawFile.size,
        bytes,
        pdf,
        libDocument: null,
        kind: "pdf",
      };

      added.push(file);
    }

    if (fileList.length && !added.length) {
      throw new Error("لم يتم العثور على ملفات PDF صالحة.");
    }

    this.files.push(...added);
    return added;
  }

  addImages(fileList) {
    const images = Array.from(fileList).filter((file) =>
      ["image/jpeg", "image/png"].includes(file.type),
    );

    if (!images.length) throw new Error("اختر صور JPG أو PNG.");

    const incomingSize = images.reduce((sum, file) => sum + file.size, 0);
    if (this.totalSize + incomingSize > this.maxTotalSize) {
      throw new Error("الحجم الإجمالي للملفات يتجاوز 350 MB.");
    }

    if (images.some(file => file.size > this.maxFileSize)) {
      throw new Error("حجم الصورة يتجاوز الحد المسموح 150 MB.");
    }
    const added = images.map((file) => ({
      id: makeId(),
      name: file.name,
      size: file.size,
      file,
      kind: "image",
    }));

    this.files.push(...added);
    return added;
  }

  remove(id) {
    const removed = this.files.find((file) => file.id === id);
    this.files = this.files.filter((file) => file.id !== id);
    return removed;
  }

  move(id, direction) {
    const index = this.files.findIndex((file) => file.id === id);
    const nextIndex = index + direction;

    if (index < 0 || nextIndex < 0 || nextIndex >= this.files.length) {
      return false;
    }

    [this.files[index], this.files[nextIndex]] = [
      this.files[nextIndex],
      this.files[index],
    ];

    return true;
  }

  clear() {
    this.files = [];
  }
}
