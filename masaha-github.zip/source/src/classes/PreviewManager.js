export class PreviewManager {
  constructor({ modal, canvas, title }) {
    this.modal = modal;
    this.canvas = canvas;
    this.title = title;
    this.pages = [];
    this.currentId = null;

    this.modal.addEventListener("click", (event) => {
      if (event.target === this.modal) this.close();
    });
  }

  setPages(pages) {
    this.pages = pages;
  }

  async draw(page, scale = 1.1) {
    const context = this.canvas.getContext("2d");

    if (page.blank) {
      this.canvas.width = Math.round(595 * scale);
      this.canvas.height = Math.round(842 * scale);
      context.fillStyle = "#fff";
      context.fillRect(0, 0, this.canvas.width, this.canvas.height);
      return;
    }

    const pdfPage = await page.pdf.getPage(page.number);
    const rotation = (pdfPage.rotate + page.rotation) % 360;
    const initial = pdfPage.getViewport({ scale, rotation });
    const factor = Math.min(1, 4096 / Math.max(initial.width, initial.height));
    const viewport =
      factor < 1
        ? pdfPage.getViewport({ scale: scale * factor, rotation })
        : initial;

    this.canvas.width = Math.ceil(viewport.width);
    this.canvas.height = Math.ceil(viewport.height);

    await pdfPage.render({
      canvasContext: context,
      viewport,
    }).promise;
  }

  async open(page) {
    this.currentId = page.id;
    this.modal.hidden = false;
    this.title.textContent = page.blank
      ? "صفحة فارغة"
      : `${page.fileName} — صفحة ${page.number}`;

    await this.draw(page);
  }

  async move(direction) {
    const index = this.pages.findIndex((page) => page.id === this.currentId);
    const next = this.pages[index + direction];
    if (next) await this.open(next);
  }

  close() {
    this.modal.hidden = true;
  }
}
