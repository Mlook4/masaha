export class ExportManager {
  constructor(app) {
    this.app = app;
    this.installOverlayControls();

    const watermarkLabel = document.querySelector('label[for="watermark"]');
    if (watermarkLabel) {
      watermarkLabel.textContent = "نص العلامة المائية";
    }

    const numberLabel = document
      .querySelector("#numberPages")
      ?.closest(".check");

    if (numberLabel) {
      const textNode = Array.from(numberLabel.childNodes).find(
        (node) => node.nodeType === Node.TEXT_NODE,
      );

      if (textNode) {
        textNode.textContent = " ترقيم الصفحات";
      }
    }
  }

  installOverlayControls() {
    if (document.querySelector("#overlaySettings")) return;

    const watermark = document.querySelector("#watermark");
    const numberPages = document.querySelector("#numberPages");
    const anchor = numberPages?.closest(".check") || watermark?.parentElement;

    if (!anchor) return;

    const settings = document.createElement("div");
    settings.id = "overlaySettings";
    settings.innerHTML = `
      <div class="section-title">تخصيص العلامة المائية</div>

      <div class="field">
        <label for="watermarkPosition">موضع العلامة</label>
        <select class="control" id="watermarkPosition">
          <option value="center">وسط الصفحة</option>
          <option value="top">أعلى الصفحة</option>
          <option value="bottom">أسفل الصفحة</option>
        </select>
      </div>

      <div class="field">
        <label for="watermarkSize">حجم العلامة</label>
        <select class="control" id="watermarkSize">
          <option value="0.06">صغير</option>
          <option value="0.09" selected>متوسط</option>
          <option value="0.13">كبير</option>
        </select>
      </div>

      <div class="field">
        <label for="watermarkOpacity">شفافية العلامة</label>
        <input
          class="control"
          id="watermarkOpacity"
          type="range"
          min="0.05"
          max="0.8"
          step="0.05"
          value="0.3"
        />
      </div>

      <div class="field">
        <label for="watermarkColor">لون العلامة</label>
        <input
          class="control"
          id="watermarkColor"
          type="color"
          value="#111111"
        />
      </div>

      <div class="section-title">تخصيص الترقيم</div>

      <div class="field">
        <label for="numberPosition">موضع رقم الصفحة</label>
        <select class="control" id="numberPosition">
          <option value="center">أسفل الوسط</option>
          <option value="right">أسفل اليمين</option>
          <option value="left">أسفل اليسار</option>
        </select>
      </div>

      <div class="field">
        <label for="numberStart">ابدأ الترقيم من</label>
        <input
          class="control"
          id="numberStart"
          type="number"
          min="1"
          step="1"
          value="1"
        />
      </div>
    `;

    anchor.insertAdjacentElement("afterend", settings);
  }

  getElement(selector) {
    return document.querySelector(selector);
  }

  getWatermarkText() {
    return this.getElement("#watermark")?.value.trim() || "";
  }

  getNumberStart() {
    const value = Number(this.getElement("#numberStart")?.value);
    return Number.isFinite(value) && value >= 1 ? Math.floor(value) : 1;
  }

  getPageNumber(index) {
    return this.getNumberStart() + index;
  }

  shouldApplyOverlay() {
    return Boolean(
      this.getWatermarkText() || this.getElement("#numberPages")?.checked,
    );
  }

  async getSource(file) {
    if (!globalThis.PDFLib) {
      throw new Error("مكتبة pdf-lib لم تُحمّل. تحقق من اتصال الإنترنت.");
    }

    if (!file.libDocument) {
      file.libDocument = await PDFLib.PDFDocument.load(file.bytes, {
        ignoreEncryption: true,
      });
    }

    return file.libDocument;
  }

  async renderPage(page, scale = 1.5) {
    const canvas = document.createElement("canvas");

    if (page.blank) {
      canvas.width = Math.round(595 * scale);
      canvas.height = Math.round(842 * scale);
      canvas.__masahaScale = scale;

      const context = canvas.getContext("2d");
      context.fillStyle = "#fff";
      context.fillRect(0, 0, canvas.width, canvas.height);

      return canvas;
    }

    const pdfPage = await page.pdf.getPage(page.number);
    const rotation = (pdfPage.rotate + page.rotation) % 360;
    const initialViewport = pdfPage.getViewport({ scale, rotation });

    const factor = Math.min(
      1,
      4096 / Math.max(initialViewport.width, initialViewport.height),
    );

    const actualScale = scale * factor;
    const viewport =
      factor < 1
        ? pdfPage.getViewport({ scale: actualScale, rotation })
        : initialViewport;

    canvas.width = Math.ceil(viewport.width);
    canvas.height = Math.ceil(viewport.height);
    canvas.__masahaScale = actualScale;

    await pdfPage.render({
      canvasContext: canvas.getContext("2d"),
      viewport,
    }).promise;

    return canvas;
  }

  addOverlay(canvas, pageNumber) {
    const context = canvas.getContext("2d");
    const watermark = this.getWatermarkText();

    if (watermark) {
      const position = this.getElement("#watermarkPosition")?.value || "center";
      const sizeRatio = Number(
        this.getElement("#watermarkSize")?.value || 0.09,
      );
      const opacity = Number(
        this.getElement("#watermarkOpacity")?.value || 0.3,
      );
      const color = this.getElement("#watermarkColor")?.value || "#111111";

      const fontSize = Math.max(18, Math.round(canvas.width * sizeRatio));

      context.save();
      context.globalAlpha = Math.max(0.05, Math.min(0.8, opacity));
      context.fillStyle = color;
      context.textAlign = "center";
      context.textBaseline = "middle";
      context.direction = "rtl";
      context.font = `bold ${fontSize}px Arial`;

      if (position === "center") {
        context.translate(canvas.width / 2, canvas.height / 2);
        context.rotate(-Math.PI / 6);
        context.fillText(watermark, 0, 0, canvas.width * 0.82);
      } else {
        const y =
          position === "top"
            ? Math.max(fontSize, canvas.height * 0.08)
            : canvas.height - Math.max(fontSize, canvas.height * 0.08);

        context.fillText(watermark, canvas.width / 2, y, canvas.width * 0.86);
      }

      context.restore();
    }

    if (this.getElement("#numberPages")?.checked) {
      const position = this.getElement("#numberPosition")?.value || "center";
      const margin = Math.max(14, canvas.height * 0.025);

      context.save();
      context.fillStyle = "#111111";
      context.textBaseline = "bottom";
      context.direction = "ltr";
      context.font = `bold ${Math.max(18, Math.round(canvas.width / 45))}px Arial`;

      if (position === "right") {
        context.textAlign = "right";
        context.fillText(
          String(pageNumber),
          canvas.width - margin,
          canvas.height - margin,
        );
      } else if (position === "left") {
        context.textAlign = "left";
        context.fillText(String(pageNumber), margin, canvas.height - margin);
      } else {
        context.textAlign = "center";
        context.fillText(
          String(pageNumber),
          canvas.width / 2,
          canvas.height - margin,
        );
      }

      context.restore();
    }
  }

  canvasToBlob(canvas, type = "image/png", quality) {
    return new Promise((resolve, reject) => {
      canvas.toBlob(
        (blob) => {
          if (blob) {
            resolve(blob);
          } else {
            reject(new Error("تعذّر تجهيز الصورة للتصدير."));
          }
        },
        type,
        quality,
      );
    });
  }

  async makeVisualPdf(records, name) {
    const output = await PDFLib.PDFDocument.create();
    const scale = 1.5;

    output.setTitle(this.getElement("#pdfTitle")?.value.trim() || name);
    output.setAuthor(this.getElement("#pdfAuthor")?.value.trim() || "مساحة");

    for (let index = 0; index < records.length; index++) {
      if (this.app.cancelled) {
        throw new Error("تم إلغاء العملية.");
      }

      const canvas = await this.renderPage(records[index], scale);
      this.addOverlay(canvas, this.getPageNumber(index));

      const png = await this.canvasToBlob(canvas, "image/png");
      const image = await output.embedPng(
        new Uint8Array(await png.arrayBuffer()),
      );

      const actualScale = canvas.__masahaScale || scale;
      const pageWidth = canvas.width / actualScale;
      const pageHeight = canvas.height / actualScale;

      const outputPage = output.addPage([pageWidth, pageHeight]);
      outputPage.drawImage(image, {
        x: 0,
        y: 0,
        width: pageWidth,
        height: pageHeight,
      });

      canvas.width = 0;

      this.app.progress(
        ((index + 1) / records.length) * 90,
        "إضافة العلامة والترقيم",
        `صفحة ${index + 1} من ${records.length}`,
      );
    }

    const bytes = await output.save();

    return {
      blob: new Blob([bytes], { type: "application/pdf" }),
      name,
      size: bytes.length,
    };
  }

  async makePdf(records, name) {
    if (!records.length) {
      throw new Error("لا توجد صفحات صالحة للتصدير.");
    }

    if (this.shouldApplyOverlay()) {
      return this.makeVisualPdf(records, name);
    }

    const output = await PDFLib.PDFDocument.create();

    output.setTitle(this.getElement("#pdfTitle")?.value.trim() || name);
    output.setAuthor(this.getElement("#pdfAuthor")?.value.trim() || "مساحة");

    for (let index = 0; index < records.length; index++) {
      if (this.app.cancelled) {
        throw new Error("تم إلغاء العملية.");
      }

      const page = records[index];

      if (page.blank) {
        output.addPage([595, 842]);
      } else {
        const source = await this.getSource(page.file);
        const [copy] = await output.copyPages(source, [page.number - 1]);

        const originalRotation = source
          .getPage(page.number - 1)
          .getRotation().angle;

        copy.setRotation(
          PDFLib.degrees((originalRotation + page.rotation) % 360),
        );

        output.addPage(copy);
      }

      this.app.progress(
        ((index + 1) / records.length) * 90,
        "إنشاء PDF",
        `صفحة ${index + 1} من ${records.length}`,
      );
    }

    const bytes = await output.save();

    return {
      blob: new Blob([bytes], { type: "application/pdf" }),
      name,
      size: bytes.length,
    };
  }

  async exportImages(pages, base, format = "jpeg") {
    const selected = pages.filter((page) => page.selected);

    if (!selected.length) {
      throw new Error("حدد صفحات لتحويلها إلى صور.");
    }

    const zip = new JSZip();
    const scale = Number(this.getElement("#quality").value) || 1.5;

    for (let index = 0; index < selected.length; index++) {
      if (this.app.cancelled) {
        throw new Error("تم إلغاء العملية.");
      }

      const canvas = await this.renderPage(selected[index], scale);
      this.addOverlay(canvas, this.getPageNumber(index));

      const mime = "image/" + format;
      const image = await this.canvasToBlob(canvas, mime, 0.9);
      if (image.type !== mime) throw new Error("متصفحك لا يدعم صيغة الصورة المطلوبة. جرّب PNG أو JPG.");
      const extension = format === "jpeg" ? "jpg" : format;
      zip.file(`page-${index + 1}.${extension}`, image);
      canvas.width = 0;

      this.app.progress(
        ((index + 1) / selected.length) * 90,
        "تصدير الصور",
        `صفحة ${index + 1} من ${selected.length}`,
      );
    }

    const blob = await zip.generateAsync({ type: "blob" });

    return {
      blob,
      name: `${base}-images.zip`,
      size: blob.size,
    };
  }

  async compress(pages, base) {
    const selected = pages.filter((page) => page.selected);

    if (!selected.length) {
      throw new Error("حدد صفحات للضغط.");
    }

    const output = await PDFLib.PDFDocument.create();
    const scale = Number(this.getElement("#quality").value) || 1.5;

    output.setTitle(this.getElement("#pdfTitle")?.value.trim() || base);
    output.setAuthor(this.getElement("#pdfAuthor")?.value.trim() || "مساحة");

    for (let index = 0; index < selected.length; index++) {
      if (this.app.cancelled) {
        throw new Error("تم إلغاء العملية.");
      }

      const canvas = await this.renderPage(selected[index], scale);
      this.addOverlay(canvas, this.getPageNumber(index));

      const jpeg = await this.canvasToBlob(canvas, "image/jpeg", 0.65);
      const image = await output.embedJpg(
        new Uint8Array(await jpeg.arrayBuffer()),
      );

      const outputPage = output.addPage([image.width, image.height]);
      outputPage.drawImage(image, {
        x: 0,
        y: 0,
        width: image.width,
        height: image.height,
      });

      canvas.width = 0;

      this.app.progress(
        ((index + 1) / selected.length) * 90,
        "ضغط بصري",
        `صفحة ${index + 1} من ${selected.length}`,
      );
    }

    const bytes = await output.save();

    return {
      blob: new Blob([bytes], { type: "application/pdf" }),
      name: `${base}-compressed.pdf`,
      size: bytes.length,
    };
  }

  async extractText(pages, base, useOcr = false) {
    const selected = pages.filter((page) => page.selected);

    if (!selected.length) {
      throw new Error("حدد صفحات أولًا.");
    }

    const sections = [];

    for (let index = 0; index < selected.length; index++) {
      if (this.app.cancelled) {
        throw new Error("تم إلغاء العملية.");
      }

      const page = selected[index];
      let text = "";

      if (useOcr) {
        if (!globalThis.Tesseract) {
          throw new Error("مكتبة OCR لم تُحمّل. تحقق من اتصال الإنترنت.");
        }

        const canvas = await this.renderPage(page, 1.7);
        const result = await Tesseract.recognize(
          canvas,
          this.getElement("#ocrLang").value,
        );

        text = result.data.text || "";
        canvas.width = 0;
      } else if (!page.blank) {
        const pdfPage = await page.pdf.getPage(page.number);
        const content = await pdfPage.getTextContent();
        text = content.items.map((item) => item.str).join(" ");
      }

      sections.push(
        `--- ${page.fileName} / صفحة ${page.number || "فارغة"} ---\n${text}`,
      );

      this.app.progress(
        ((index + 1) / selected.length) * 90,
        useOcr ? "OCR" : "استخراج النص",
        `صفحة ${index + 1} من ${selected.length}`,
      );
    }

    if (!useOcr) {
      const blob = new Blob(["\uFEFF", sections.join("\n\n")], {
        type: "text/plain;charset=utf-8",
      });

      return {
        blob,
        name: `${base}.txt`,
        size: blob.size,
      };
    }

    const html = `<!doctype html>
      <html>
      <head><meta charset="utf-8"></head>
      <body dir="rtl" style="font-family:Arial">
        ${sections
          .map(
            (section) =>
              `<pre style="white-space:pre-wrap">${this.escapeHtml(section)}</pre><hr>`,
          )
          .join("")}
      </body>
      </html>`;

    const blob = new Blob(["\uFEFF", html], {
      type: "application/msword;charset=utf-8",
    });

    return {
      blob,
      name: `${base}.doc`,
      size: blob.size,
    };
  }

  escapeHtml(value) {
    return String(value)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;");
  }

  async imagesToPdf(base) {
    const imageFiles = this.app.files.files.filter(
      (file) => file.kind === "image",
    );

    if (!imageFiles.length) {
      throw new Error("أضف صورًا أولًا.");
    }

    const output = await PDFLib.PDFDocument.create();
    const size = this.getElement("#imageSize").value;
    const addOverlay = this.shouldApplyOverlay();

    output.setTitle(this.getElement("#pdfTitle").value.trim() || base);
    output.setAuthor(this.getElement("#pdfAuthor").value.trim() || "مساحة");

    for (let index = 0; index < imageFiles.length; index++) {
      if (this.app.cancelled) {
        throw new Error("تم إلغاء العملية.");
      }

      const file = imageFiles[index];
      let image;
      let imageWidth;
      let imageHeight;

      if (addOverlay) {
        const bitmap = await createImageBitmap(file.file);
        const scale = Math.min(1, 4096 / Math.max(bitmap.width, bitmap.height));
        const canvas = document.createElement("canvas");

        canvas.width = Math.max(1, Math.round(bitmap.width * scale));
        canvas.height = Math.max(1, Math.round(bitmap.height * scale));

        const context = canvas.getContext("2d");
        context.fillStyle = "#fff";
        context.fillRect(0, 0, canvas.width, canvas.height);
        context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
        bitmap.close?.();

        this.addOverlay(canvas, this.getPageNumber(index));

        const png = await this.canvasToBlob(canvas, "image/png");
        image = await output.embedPng(new Uint8Array(await png.arrayBuffer()));

        imageWidth = canvas.width;
        imageHeight = canvas.height;
        canvas.width = 0;
      } else {
        const bytes = new Uint8Array(await file.file.arrayBuffer());

        image =
          file.file.type === "image/png"
            ? await output.embedPng(bytes)
            : await output.embedJpg(bytes);

        imageWidth = image.width;
        imageHeight = image.height;
      }

      let width = imageWidth;
      let height = imageHeight;

      if (size === "image") {
        const page = output.addPage([width, height]);
        page.drawImage(image, { x: 0, y: 0, width, height });
      } else {
        const paper = size === "a4" ? [595.28, 841.89] : [612, 792];
        const scale = Math.min(paper[0] / width, paper[1] / height);

        width *= scale;
        height *= scale;

        const page = output.addPage(paper);
        page.drawImage(image, {
          x: (paper[0] - width) / 2,
          y: (paper[1] - height) / 2,
          width,
          height,
        });
      }

      this.app.progress(
        ((index + 1) / imageFiles.length) * 90,
        "تحويل الصور إلى PDF",
        `صورة ${index + 1} من ${imageFiles.length}`,
      );
    }

    const bytes = await output.save();

    return {
      blob: new Blob([bytes], { type: "application/pdf" }),
      name: `${base}.pdf`,
      size: bytes.length,
    };
  }

  async pdfToPowerPoint(pages, base) {
    if (!pages.length) throw new Error("أضف صفحات أولًا.");
    const PptxConstructor = globalThis.pptxgen || globalThis.PptxGenJS;
    if (!PptxConstructor) throw new Error("تعذر تحميل مكتبة PowerPoint. افتح النسخة الكاملة من التطبيق.");
    const presentation = new PptxConstructor();
    presentation.layout = "LAYOUT_WIDE";
    presentation.author = "مساحة"; presentation.subject = "صفحات PDF كصور";
    presentation.title = base; presentation.lang = "ar-SA";
    for (let index=0; index<pages.length; index++) {
      if (this.app.cancelled) throw new Error("تم إلغاء العملية.");
      const canvas = await this.renderPage(pages[index], 1.5);
      try {
        const scale = Math.min(13.333333 / canvas.width, 7.5 / canvas.height);
        const w = canvas.width*scale, h = canvas.height*scale;
        const slide = presentation.addSlide(); slide.background = {color:"FFFFFF"};
        slide.addImage({data:canvas.toDataURL("image/png"),x:(13.333333-w)/2,y:(7.5-h)/2,w,h});
      } finally {canvas.width=0;canvas.height=0;}
      this.app.progress((index+1)/pages.length*90,"إنشاء PowerPoint","شريحة "+(index+1)+" من "+pages.length);
    }
    const bytes = await presentation.write({outputType:"arraybuffer"});
    const blob = new Blob([bytes], {type:"application/vnd.openxmlformats-officedocument.presentationml.presentation"});
    return {blob,name:base+".pptx",size:blob.size};
  }

  async exportDocumentTool(operation, pages, base) {
    const selected = pages.filter(p => p.selected && !p.deleted);
    if (!selected.length) throw new Error("حدد صفحات أولًا.");
    if (operation === "cropPdf") {
      const percent = Number(this.getElement("#cropPercent").value);
      if (!Number.isFinite(percent) || percent < 0 || percent > 30) throw new Error("نسبة القص يجب أن تكون بين ٠ و٣٠.");
      const output = await PDFLib.PDFDocument.create();
      for (const page of selected) {
        if (this.app.cancelled) throw new Error("تم إلغاء العملية.");
        if (page.blank) {output.addPage([595,842]);continue;}
        const source = await this.getSource(page.file);
        const [copy] = await output.copyPages(source,[page.number-1]);
        const box=copy.getCropBox(), dx=box.width*percent/100, dy=box.height*percent/100;
        copy.setCropBox(box.x+dx,box.y+dy,box.width-2*dx,box.height-2*dy);
        copy.setRotation(PDFLib.degrees((copy.getRotation().angle+page.rotation)%360));output.addPage(copy);
      }
      const bytes=await output.save();const blob=new Blob([bytes],{type:'application/pdf'});return {blob,name:base+'.pdf',size:blob.size};
    }
    const sections=[];
    for(let i=0;i<selected.length;i++) {
      if(this.app.cancelled) throw new Error("تم إلغاء العملية.");
      const page=selected[i];let text='';
      if(!page.blank){const pdfPage=await page.pdf.getPage(page.number);const content=await pdfPage.getTextContent();text=content.items.map(item=>(item.str||'')+(item.hasEOL?'\n':' ')).join('').trim();}
      sections.push({fileId:page.file?.id,name:page.fileName,page:page.number,text});
      this.app.progress((i+1)/selected.length*85,'استخراج النص',`صفحة ${i+1}`);
    }
    if (!sections.some(s=>s.text)) throw new Error("لا يوجد نص مضمّن. استخدم OCR للملفات المصوّرة.");
    if(operation==='pdfWord') {
      const escape=s=>this.escapeHtml(s).replaceAll("'",'&apos;');
      const paragraphs=sections.map(section=>'<w:p><w:r><w:t>'+escape('صفحة '+section.page)+'</w:t></w:r></w:p>'+section.text.split('\n').map(line=>'<w:p><w:pPr><w:bidi/></w:pPr><w:r><w:rPr><w:rtl/></w:rPr><w:t xml:space="preserve">'+escape(line)+'</w:t></w:r></w:p>').join('')).join('<w:p><w:r><w:br w:type="page"/></w:r></w:p>');
      const zip=new JSZip();
      zip.file('[Content_Types].xml','<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>');
      zip.file('_rels/.rels','<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>');
      zip.file('word/document.xml','<?xml version="1.0" encoding="UTF-8"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>'+paragraphs+'<w:sectPr/></w:body></w:document>');
      const bytes=await zip.generateAsync({type:'arraybuffer'});const blob=new Blob([bytes],{type:'application/vnd.openxmlformats-officedocument.wordprocessingml.document'});return {blob,name:base+'.docx',size:blob.size};
    }
    const groups=new Map();sections.forEach(s=>{if(!groups.has(s.fileId))groups.set(s.fileId,{name:s.name,text:[]});groups.get(s.fileId).text.push(s.text);});
    if(groups.size!==2) throw new Error("أضف ملفين بالضبط وحدد صفحات من كل ملف للمقارنة.");
    const [left,right]=[...groups.values()];const a=left.text.join('\n').split('\n'),b=right.text.join('\n').split('\n');
    const rows=Array.from({length:Math.max(a.length,b.length)},(_,i)=>{const same=(a[i]||'').trim()===(b[i]||'').trim();return '<tr style="background:'+(same?'white':'#fff4ce')+'"><td>'+this.escapeHtml(a[i]||'')+'</td><td>'+this.escapeHtml(b[i]||'')+'</td><td>'+(same?'متطابق':'مختلف')+'</td></tr>';}).join('');
    const html='<!doctype html><meta charset="utf-8"><title>مقارنة نصوص</title><body dir="rtl"><h1>مقارنة نصية حسب ترتيب الأسطر</h1><p>الأصفر يوضح اختلاف الأسطر. إدراج سطر قد يغيّر محاذاة الأسطر التالية. لا تشمل المقارنة الرسومات أو التنسيق.</p><table border="1" cellpadding="10" style="border-collapse:collapse;white-space:pre-wrap"><tr><th>'+this.escapeHtml(left.name)+'</th><th>'+this.escapeHtml(right.name)+'</th><th>الحالة</th></tr>'+rows+'</table></body>';
    const blob=new Blob([html],{type:'text/html;charset=utf-8'});return {blob,name:base+'-comparison.html',size:blob.size};
  }

  async export(operation, pages, ranges) {
    pages = pages.filter(page => !page.deleted);
    const base = this.app.safeName(this.getElement("#outputName").value);

    if (["reversePdf", "oddPdf", "evenPdf"].includes(operation)) {
      const output = operation === "reversePdf" ? [...pages].reverse() : pages.filter((_, i) => i % 2 === (operation === "oddPdf" ? 0 : 1));
      if (!output.length) throw new Error("لا توجد صفحات مناسبة لهذه العملية.");
      return this.makePdf(output, base + ".pdf");
    }
    if (operation === "splitHalf") {
      if (pages.length < 2) throw new Error("تحتاج صفحتين على الأقل للتقسيم إلى نصفين.");
      const middle = Math.ceil(pages.length / 2);
      return this.export("splitRanges", pages, [{from:1,to:middle},{from:middle+1,to:pages.length}]);
    }
    if (["pdfWord", "comparePdf", "cropPdf"].includes(operation)) return this.exportDocumentTool(operation, pages, base);
    if (operation === "pdfPowerpoint") return this.pdfToPowerPoint(pages, base);
    if (operation === "watermarkPdf") {
      if (!this.getWatermarkText()) throw new Error("اكتب نص العلامة المائية في الخيارات الإضافية أولًا.");
      return this.makePdf(pages, base + ".pdf");
    }
    if (operation === "numberPdf") {
      if (!this.getElement("#numberPages").checked) throw new Error("فعّل ترقيم الصفحات في الخيارات الإضافية.");
      return this.makePdf(pages, base + ".pdf");
    }
    if (operation === "pdfMarkdown") {
      const selected = pages.filter(page => page.selected);
      if (!selected.length) throw new Error("حدد صفحات أولًا.");
      const sections = [];
      for (let i = 0; i < selected.length; i++) {
        if (this.app.cancelled) throw new Error("تم إلغاء العملية.");
        const page = selected[i]; let lines = "";
        if (!page.blank) {
          const pdfPage = await page.pdf.getPage(page.number);
          const content = await pdfPage.getTextContent();
          lines = content.items.map(item => String(item.str || "").replace(/([\\`*_{}\[\]<>#])/g, "\\$1") + (item.hasEOL ? "\n" : " ")).join("").trim();
        }
        sections.push("## صفحة " + (page.number || "فارغة") + "\n\n" + lines);
        this.app.progress((i+1)/selected.length*90, "استخراج Markdown", "صفحة " + (i+1));
      }
      const blob = new Blob(["\uFEFF", sections.join("\n\n---\n\n")], {type:"text/markdown;charset=utf-8"});
      return {blob, name:base+".md", size:blob.size};
    }
    if (operation === "merge" || operation === "repair") {
      return this.makePdf(pages, `${base}.pdf`);
    }

    if (operation === "extract") {
      const selected = pages.filter((page) => page.selected);
      if (!selected.length) throw new Error("حدد صفحات للتصدير.");

      return this.makePdf(selected, `${base}-selected.pdf`);
    }

    if (operation === "delete") {
      const remaining = pages.filter((page) => !page.selected);
      if (!remaining.length) {
        throw new Error("لا توجد صفحات متبقية للتصدير.");
      }

      return this.makePdf(remaining, `${base}-edited.pdf`);
    }

    if (operation === "splitRanges") {
      if (!ranges.length) {
        throw new Error("أضف نطاقًا واحدًا على الأقل.");
      }

      const zip = new JSZip();

      for (let index = 0; index < ranges.length; index++) {
        if (this.app.cancelled) {
          throw new Error("تم إلغاء العملية.");
        }

        const range = ranges[index];
        const result = await this.makePdf(
          pages.slice(range.from - 1, range.to),
          `${base}-${range.from}-${range.to}.pdf`,
        );

        zip.file(result.name, result.blob);
        this.app.progress(
          ((index + 1) / ranges.length) * 90,
          "إنشاء ملفات النطاقات",
          `النطاق ${index + 1} من ${ranges.length}`,
        );
      }

      const blob = await zip.generateAsync({ type: "blob" });

      return {
        blob,
        name: `${base}-ranges.zip`,
        size: blob.size,
      };
    }

    if (operation === "splitEach") {
      const selected = pages.filter((page) => page.selected);

      if (!selected.length) {
        throw new Error("حدد صفحات للتقسيم.");
      }

      const zip = new JSZip();

      for (let index = 0; index < selected.length; index++) {
        if (this.app.cancelled) {
          throw new Error("تم إلغاء العملية.");
        }

        const result = await this.makePdf(
          [selected[index]],
          `${base}-page-${index + 1}.pdf`,
        );

        zip.file(result.name, result.blob);
        this.app.progress(
          ((index + 1) / selected.length) * 90,
          "تقسيم الصفحات",
          `صفحة ${index + 1} من ${selected.length}`,
        );
      }

      const blob = await zip.generateAsync({ type: "blob" });

      return {
        blob,
        name: `${base}-pages.zip`,
        size: blob.size,
      };
    }

    if (operation === "compress") {
      return this.compress(pages, base);
    }

    if (operation === "imagesPng" || operation === "imagesWebp") {
      return this.exportImages(pages, base, operation === "imagesPng" ? "png" : "webp");
    }
    if (operation === "images") {
      return this.exportImages(pages, base);
    }

    if (operation === "imagesPdf") {
      return this.imagesToPdf(base);
    }

    if (operation === "text") {
      return this.extractText(pages, base, false);
    }

    if (operation === "ocr") {
      return this.extractText(pages, base, true);
    }

    throw new Error("عملية التصدير غير مدعومة.");
  }
}
