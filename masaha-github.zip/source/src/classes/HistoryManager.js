export class HistoryManager {
  constructor(onChange = () => {}) {
    this.undoStack = [];
    this.redoStack = [];
    this.onChange = onChange;
  }

  clone(pages) {
    return pages.map((page) => ({ ...page }));
  }

  save(pages) {
    this.undoStack.push(this.clone(pages));
    if (this.undoStack.length > 40) this.undoStack.shift();
    this.redoStack = [];
    this.notify();
  }

  undo(currentPages) {
    if (!this.undoStack.length) return null;
    this.redoStack.push(this.clone(currentPages));
    const previous = this.undoStack.pop();
    this.notify();
    return previous;
  }

  redo(currentPages) {
    if (!this.redoStack.length) return null;
    this.undoStack.push(this.clone(currentPages));
    const next = this.redoStack.pop();
    this.notify();
    return next;
  }

  canUndo() {
    return this.undoStack.length > 0;
  }

  canRedo() {
    return this.redoStack.length > 0;
  }

  clear() {
    this.undoStack = [];
    this.redoStack = [];
    this.notify();
  }

  notify() {
    this.onChange(this.canUndo(), this.canRedo());
  }
}
